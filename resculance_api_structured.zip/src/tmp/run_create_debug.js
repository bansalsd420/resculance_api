const OrganizationModel = require('../models/Organization');

(async () => {
  try {
    const id = await OrganizationModel.create({
      name: 'SCRIPTS ORG',
      code: 'SCR-1',
      type: 'HOSPITAL',
      address: 'Script Address',
      city: 'ScriptCity',
      state: 'ScriptState',
      zipCode: '54321',
      phone: '1234500000',
      email: 'script@org.test',
      licenseNumber: 'LIC-SCRIPT'
    });
    console.log('Created org id:', id);
    process.exit(0);
  } catch (err) {
    console.error('Create error:', err);
    process.exit(1);
  }
})();