const db = require('../config/database');

(async () => {
  try {
    const [rows] = await db.query("SHOW COLUMNS FROM organizations");
    console.log('columns:', rows.map(r => ({ Field: r.Field, Type: r.Type })));
    process.exit(0);
  } catch (err) {
    console.error('error querying columns:', err.message);
    process.exit(1);
  }
})();
